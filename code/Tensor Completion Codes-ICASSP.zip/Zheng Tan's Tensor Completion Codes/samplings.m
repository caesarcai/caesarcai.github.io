%Set the size of the sampling operator
N1 = 120;
N2 = 120;
N3 = 120;


%Uniform sampling columns, same for each frontal slice
T = zeros(N1, N2, N3);
rand_column = randi([1, N2]);
for i=1:N3
    %Choose a random column and spread to the two directions
    for j=1:N2
        if mod(j-rand_column, 5) == 0
            T(:, j, i) = ones(N1, 1);
        end
    end
end
circ_T = zeros(N1*N3, N2*N3);
for j=1:N3
    for i=1:N3
        current_round = mod(i+j-2, N3);
        circ_T(current_round*N1+1:(current_round+1)*N1,(j-1)*N2+1:j*N2) = T(:,:,i);
    end
end

%Uniform sampling columns, different for each frontal slice
T2 = zeros(N1, N2, N3);
for i=1:N3
    %Choose a random column and spread to the two directions
    rand_column = randi([1, N2]);
    for j=1:N2
        if mod(j-rand_column, 5) == 0
            T2(:, j, i) = ones(N1, 1);
        end
    end
end
circ_T2 = zeros(N1*N3, N2*N3);
for j=1:N3
    for i=1:N3
        current_round = mod(i+j-2, N3);
        circ_T2(current_round*N1+1:(current_round+1)*N1,(j-1)*N2+1:j*N2) = T2(:,:,i);
    end
end



%Randomly sampling columns for each frontal slice
T3 = zeros(N1, N2, N3);
for i=1:N3
    %Choose a random column and spread to the two directions
    cols = randsample(N2, round(N2*0.2));
    cols = sort(cols);
    my_len = length(cols);
    current_index = 1;
    for j=1:N1
        if current_index > my_len
            break
        end
        if j == cols(current_index)
            T3(:, j, i) = ones(N1, 1);
            current_index = current_index + 1;
        end
    end
end
circ_T3 = zeros(N1*N3, N2*N3);
for j=1:N3
    for i=1:N3
        current_round = mod(i+j-2, N3);
        circ_T3(current_round*N1+1:(current_round+1)*N1,(j-1)*N2+1:j*N2) = T3(:,:,i);
    end
end




figure(1)
subplot(1, 3, 1);
imshow(circ_T);
title("Uniform Column, Same")
subplot(1, 3, 2);
imshow(circ_T2);
title("Uniform Column, Different")
subplot(1, 3, 3);
imshow(circ_T3);
title("Random Column")


% figure(2)
% plot(sum(circ_T,1));
