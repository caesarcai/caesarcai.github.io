close all; clear all; clc;
dim = [200, 200];      
m = dim(1);
n = dim(2); 
r = 5; %rank of the optimal matrix

params_CCS.p = 0.5; %uniform observation rate on the submatrices
params_CCS.delta = 0.5;%percentage of sampled columns or rows

%params_ICURC.eta = [1/params_CCS.p, 1/params_CCS.p, 1/(2*params_CCS.p)]; %step sizes for updating C, R, and U
params_ICURC.TOL = 1e-5;
params_ICURC.max_ite = 1000;
%%
%Generate the underlying matrix with rank = r
A = rand(m, n);
[U, S, V] = svd(A);
for i=(r+1):min(m,n)
    S(i,i) = 0;
end
X = U*S*V';
X = X .* 100;
disp(rank(X));

%Generate sampling matrix
sampling_mat = zeros(m, n);
sampling_ratio = 0.25;
temp = reshape(sampling_mat, 1, []);
temp(randsample(m*n,round(m*n*sampling_ratio))) = 1;
sampling_mat = reshape(temp, m, n);

X_sampled = X .* sampling_mat;
%Generate observed data under CCS with give p and delta
[X_Omega_UR, I_css, J_css] = CCS(X_sampled, params_CCS); 

fprintf('Running ICURC with m=%d, n=%d, r=%f...\n',m,n,r);
%Run ICURC 
[C,U_pinv,R, ICURC_time] = ICURC_v2(X_sampled, r, params_ICURC, 1, I_css, J_css, X_Omega_UR);
Mout_CURf = C*U_pinv*R; 
Error1 = norm(Mout_CURf - X,'fro') / norm(X,'fro');
[C,U_pinv,R, ICURC_time2] = ICURC_v2(X_sampled, r, params_ICURC, 1000, I_css, J_css, X_Omega_UR);
Mout_CURf = C*U_pinv*R; 
Error2 = norm(Mout_CURf - X,'fro') / norm(X,'fro');



%%
fprintf('ICURC finished with relative error in frobenius norm =%f in time t=%f \n',Error1,ICURC_time);
fprintf('ICURC finished with relative error in frobenius norm =%f in time t=%f \n',Error2,ICURC_time2);
