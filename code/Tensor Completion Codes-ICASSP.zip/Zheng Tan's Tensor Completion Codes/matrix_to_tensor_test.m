clear all;

%Randomly generate a matrix
m = 64;
n = 64;
M = rand(m, n);
M = M * 10;

r = 5;
[U, S, V] = svd(M);
[s1, s2] = size(S);
for i=1:min(s1, s2)
    if i > r
        S(i, i) = 0;
    end
end 
M = U * S * V';
disp(rank(M));

sample_ratio = 0.3;
proximal_type = "TNN";
max_iteration = 1500;

%Randomly sample columns
sampling_matrix = zeros(m, n);
cols = randsample(n, round(n*sample_ratio));
cols = sort(cols);
my_len = length(cols);
current_index = 1;
for j=1:n
    if current_index > my_len
        break
    end
    if j == cols(current_index)
        sampling_matrix(:, j) = ones(m, 1);
        current_index = current_index + 1;
    end
end

% %Random Sampling
% sampling_matrix = zeros(m, n);
% temp = reshape(sampling_matrix(:,:), 1, []);
% temp(randsample(m*n,round(m*n*sample_ratio))) = 1;
% sampling_matrix(:,:) = reshape(temp, m, n);


%Turn matrix into a tensor
%Each frontal slice is a permutation of the original matrix
l = 64;
T = zeros(m, n, l);
sampling_tensor = zeros(m, n, l);
for i=1:l
    if i == 1
        T(:,:,i) = M;
        sampling_tensor(:,:,i) = sampling_matrix;
    else
        current_perm = randperm(m);
        T(:,:,i) = M(current_perm, :);
        sampling_tensor(:,:,i) = sampling_matrix(current_perm, :);
    end
end
T_sampled = sampling_tensor .* T;




%Do the Tensor ADMM process
T_used = T_sampled;
X = T_used;
Y = X;
W = zeros(m, l, n);

%The lambda and ro value to be tuned
switch proximal_type
    case "TNN"
        lambda = 10^-6;
        ro = 10^-8;
    case "TL1"
        lambda = 10^-7;
        ro = 10^-9;
    case "L12"
        lambda = 10^-6;
        ro = 10^-8;
    case "Lp"
        lambda = 10^-6;
        ro = 10^-8;
end




%Auxiliary tensor as a Hadamard operator
I = ones(m, l, n);

relative_error_list = {};
relative_error_list_mat = {};

count = 0;
while true
    count = count + 1;
    %X problem
    YW_temp = fft(Y-W, [], 3);
    [N1, N2, N3] = size(YW_temp);
    U = zeros(N1, N1, N3);
    S = zeros(N1, N2, N3);
    V = zeros(N1, N1, N3);
    for i=1:n
        [U(:,:,i), S(:,:,i), V(:,:,i)] = svd(YW_temp(:,:,i));
        diagonal = diag(S(:,:,i));
        %Different Proximal Types
        switch proximal_type
            case "TNN"
                diagonal_shrink = max(abs(diagonal)-lambda/ro, 0).*sign(diagonal);
            case "TL1"
                diagonal_shrink = shrinkTL1(diagonal, lambda/ro, 10^10);
            case "L12"
                [diagonal_shrink, ~] = shrinkL12(diagonal, lambda/ro, 1/10^20);
            case "Lp"
                diagonal_shrink = shrinkLp(diagonal, lambda);
            otherwise
                disp("Invalid proximal type");
        end
        S(:,:,i) = diag(diagonal_shrink);
        YW_temp(:,:,i) = U(:,:,i)*S(:,:,i)*V(:,:,i)';
    end
    X = ifft(YW_temp, [], 3);
    %Y problem
    Y = (sampling_tensor.*T_sampled-ro*X-ro*W)./(sampling_tensor-ro*I);
    %W problem
    W = W + (X-Y);
    relative_error_list{end+1} = norm(X(:)-T(:), "fro")/norm(T(:), "fro");
    relative_error_list_mat{end+1} = norm(X(:,:,1)-T(:,:,1), "fro")/norm(T(:,:,1), "fro");
    if count >= max_iteration
        T_completed = X;
        relative_error = norm(X(:)-T(:), "fro")/norm(T(:), "fro");
        break;
    end
end

disp("Tensor Relative Error: " + relative_error);
relative_error_mat = norm(T_completed(:,:,1)-T(:,:,1), "fro")/norm(T(:,:,1), "fro");
disp("Matrix Relative Error: " + relative_error_mat);

relative_error_list = cell2mat(relative_error_list);
relative_error_list_mat = cell2mat(relative_error_list_mat);

grid = zeros(max_iteration, 1);
for i=1:max_iteration
    grid(i) = i;
end

figure(1)
semilogy(grid, relative_error_list, 'color', 'cyan');
figure(2)
semilogy(grid, relative_error_list_mat, 'color', 'cyan');



% -----------------------------------------
%Lambda same as the ADMM shrinkage input (lambda/ro)
%a could be 1(to be tuned later)
function v = shrinkTL1(s,lambda,a)
    % closed-form solution for minimize_v lambda f(v)+0.5||s-v||^2
    
    phi = acos(1-(0.5*27*lambda*a*(a+1))./(a+abs(s)).^3);
    
    v = sign(s).*(2/3 * (a+abs(s)).* cos(phi/3) -2*a/3+abs(s)/3).*(abs(s)>lambda);
   
end



% -----------------------------------------
%Lambda same as the ADMM shrinkage input (lambda/ro)
function [x,output] = shrinkL12(y,lambda,alpha)
    % closed-form solution for minimize_x lambda f(x)+0.5||x-y||^2
    x = zeros(size(y));
    
    if nargin<3
        alpha = 1;
    end
    
    output = 0;
    
    if max(abs(y)) > 0 
        if max(abs(y)) > lambda
            x = max(abs(y)-lambda,0).*sign(y);
            x = x*(norm(x)+alpha*lambda)/norm(x);
            output = 1;
        else
            if max(abs(y))>=(1-alpha)*lambda
                [~, i] = max(abs(y));
                x(i(1)) = (y(i(1))+(alpha-1)*lambda)*sign(y(i(1)));
            end
            output = 2;
        end
    end

end


% -----------------------------------------
%r is the same as lambda??
function z = shrinkLp(x,r)
    % closed-form solution for minimize_x r f(x)+0.5||x-z||^2
    % z = sign(x).*max(abs(x)-r,0);
    z = zeros(size(x));
    phi = acos(r./8*((abs(x)./3).^(-1.5)));
    idx = abs(x)>=3/4*(r^(2/3));
    z(idx)= 4.*x(idx)./3.*(cos(((pi)/3)-phi(idx)./3)).^2;
    return; 
end









