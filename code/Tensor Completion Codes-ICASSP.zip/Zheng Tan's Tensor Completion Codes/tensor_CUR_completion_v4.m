%Tensor CUR Completion
%This is a tensor cross sampling specific CUR algorithm;
%Parameters: T is the entire low rank tensor; 
% sampling_tensor is a tensor with 1 and 0
% sample_ratio is the sampling ratio for the observed tensor;
% I_ccs, J_ccs are the selected row indices and column indices, respectively;
% expected_rank is the expected tubal rank of the completed tensor; for
% convenience, in test it's set to be the actual tubal rank of T;
% max_iteration is the maximum number of iterations in the matrix CUR process.
function [T_completed, fro_error] = tensor_CUR_completion_v4(T, sampling_tensor, I_ccs, J_ccs, expected_rank, delta, max_iteration)
    %The sampled part
    T_sampled = sampling_tensor .* T;
    T_test = fft(T, [], 3);

    [m, n, o] = size(T);
    T_transformed = fft(T_sampled, [], 3);

    %Try to reduce the tolerance
    params_icurc.TOL = 1e-6;
    params_icurc.max_ite = max_iteration;


    
    X = T_transformed(:,:,1);
    [C, U_pinv, R, ~] = ICURC_resample(X, I_ccs, J_ccs, expected_rank, 0.05, params_icurc);
%     X_completed = C*U_pinv*R;
%     disp("Current i is 1");
%     disp(norm(X_completed-T_test(:,:,1), 'fro')/norm(T_test(:,:,1),'fro'));
    
    [rownums, ~] = size(I_ccs);
    [colnums, ~] = size(J_ccs);
    C_transformed = zeros(m, colnums, o);
    U_transformed = zeros(colnums, rownums, o);
    R_transformed = zeros(rownums, n, o);

    C_transformed(:,:,1) = C;
    U_transformed(:,:,1) = U_pinv;
    R_transformed(:,:,1) = R;


    
    %The first frontal slice is done by ADMM instead
    %Still can't figure out what's wrong with the first frontal slice
    for i=2:o
        X = T_transformed(:,:,i);

        [C,U_pinv,R, ~] = ICURC_resample(X, I_ccs, J_ccs, expected_rank, delta, params_icurc);

        C_transformed(:,:,i) = C;
        U_transformed(:,:,i) = U_pinv;
        R_transformed(:,:,i) = R;

%         disp("Current i is " + i);
%         disp(norm(C*U_pinv*R-T_test(:,:,i), 'fro')/norm(T_test(:,:,i), 'fro'));
    end
    C_tensor = ifft(C_transformed, [], 3); 
    U_tensor = ifft(U_transformed, [], 3); 
    R_tensor = ifft(R_transformed, [], 3); 
    T_completed = t_product(C_tensor, t_product(U_tensor, R_tensor));

    T_completed = real(T_completed);


    %Frobenius Norm Error
    fro_error = norm(T(:)-T_completed(:), 'fro')/norm(T(:), 'fro');
%     disp("Frobenius Norm Error: " + fro_error);

end






