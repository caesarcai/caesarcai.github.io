%Tensor CUR Completion
%Parameters: T is the entire low rank tensor; 
% sampling_type is one of {"fully random", "random column", "uniform column"}; 
% sample_ratio is the sampling ratio for the observed tensor;
% d/l are vectors of sample cols/rows in CUR; 
% max_iteration is the maximum number of iterations in the matrix CUR process.
function [T_completed, fro_error, fro_error_list] = tensor_CUR_completion_v2(T, sampling_tensor, L1, L2, max_iteration, tol, domain)
    %The sampled part
    T_sampled = sampling_tensor .* T;

    [N1, N2, N3] = size(T);

    X_current = T_sampled;

    one_tensor = ones(N1, N2, N3);
    non_sampling_tensor = one_tensor-sampling_tensor;

    iter = 0;
    fro_error_list = {};
    while true
        iter = iter + 1;
%         Y = TubSamplsmooth_fast(X_current, L1, L2);
        if domain ~= "Fourier"
            Y = TubSamplsmooth(X_current, L1, L2);
        else
            Y = FTubSamplsmooth(X_current, L1, L2);
        end
        X_previous = X_current;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %Stopping condition: calculate relative error on observed part
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        X_current = sampling_tensor .* X_current + non_sampling_tensor.* Y;
        fro_error = norm(X_current(:) - T(:), 'fro')/norm(T(:), 'fro');
        fro_error_list{end+1} = fro_error;
        if fro_error < tol || iter >= max_iteration
            T_completed = X_current;
            disp("Iteration number " + iter);
            fro_error_list = cell2mat(fro_error_list);
            break;
        end
    end
    


    %Frobenius Norm Error
    fro_error = norm(T(:)-T_completed(:), 'fro')/norm(T(:), 'fro');
    disp("Frobenius Norm Error: " + fro_error);
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Helper functions

%Calculate MP pseudoinverse
function [X_pinv] = t_pinv(X)
    [n1, n2, n3] = size(X);
    X_pinv = zeros([n2, n1, n3]);
    
    X = fft(X, [], 3);
    for i=1:n3
        X_pinv(:,:,i) = pinv(X(:,:,i));
    end   
    X_pinv = ifft(X_pinv, [], 3);
end

%CUR-based completion
function Y=TubSamplsmooth(X,R1,R2)
    N_m=size(X);
    
    r1=randsample(N_m(2),R1);
    C=X(:,r1,:);

    r2=randsample(N_m(1),R2);
    R=X(r2,:,:);

    U=t_product(t_product(t_pinv(C),X),t_pinv(R));

    Y=t_product(t_product(C,U),R);
end

%CUR-based completion in Fourier mode
function Z=FTubSamplsmooth(X,R1,R2)
    N_m=size(X);
    
    r1=randsample(N_m(2),R1);
    C=X(:,r1,:);

    r2=randsample(N_m(1),R2);
    R=X(r2,:,:);

    FX = fft(X, [], 3);
    FC = fft(C, [], 3);
    FR = fft(R, [], 3);

    FU = zeros(R1, R2, N_m(3));
    FZ = zeros(N_m(1), N_m(2), N_m(3));

    for i=1:N_m(3)
        FU(:,:,i) = pinv(FC(:,:,i))*FX(:,:,i)*pinv(FR(:,:,i));
    end
    for i=1:N_m(3)
        FZ(:,:,i) = FC(:,:,i)*FU(:,:,i)*FR(:,:,i);
    end

    Z = ifft(FZ, [], 3);
end

%CUR-based completion faster
function Y=TubSamplsmooth_fast(X,R1,R2)
    N_m=size(X);
    
    r1=randsample(N_m(2),R1);
    C=X(:,r1,:);

    r2=randsample(N_m(1),R2);
    R=X(r2,:,:);

    W = X(r2, r1, :);
    U=t_product(t_product(C,t_pinv(W)), R);

    Y=t_product(t_product(C,U),R);
end












