 function [C,U_pinv,R, ICURC_time] = ICURC_resample(X_Omega, I_ccs, J_ccs, r, delta, params_ICURC)

%Return the CUR components of result of solved Matrix Completion problem

%under Cross-Concentrated Sampling (CCS). 

%

%Inputs:

%   X_Omega_css - observed data matrix based on CSS sampling model

%   I_css - row indices of the selected row submatrix

%   J_css - column indices of the selected column submatrix

%   r : rank of targt X

%   params_ICURC - parameter structure containing the following fields:

%       TOL,max_ite - stopping crICURC_iteria

%           defaults = 1e-4 (TOL), 500 (mxitr)

%       eta - step size

%           default = [1, 1, 1] for [eta_C, eat_R, era_U], step sizes for

%           updating C, R, and U respectively 

%       steps_are1 - if all step sizes are 1

%           default = true


%Outputs:

%   C, U_pinv, R - The CUR components of recovered X

%   ICURC_time -Function execution time

%   ICURC_ite - Number of ICURC_iterations required

% if(~exist('params_ICURC','var'))
%     params_ICURC=struct();
% end
% params_ICURC = SetDefaultParams_ICURC(params_ICURC);

    %eta=params_ICURC.eta;
    TOL=params_ICURC.TOL;
    max_ite=params_ICURC.max_ite;
    
    
    %If all step sizes are 1
    fct_time = tic;
    
    [m,n] = size(X_Omega);
    
    num_r = round(m*delta);
    num_c = round(n*delta);
    I = randsample(m,num_r,false);
    J = randsample(n,num_c,false);  
    C = X_Omega(:,J);
    R = X_Omega(I,:);
    U = X_Omega(I,J);
    Samp_ind = (X_Omega~=0);
    [u,s,v] = svd(U);
    U_pinv = v(:,1:r)*pinv(s(1:r,1:r))*(u(:,1:r))';
    
    for ICURC_ite = 1:max_ite
        I = randsample(m,num_r,false);
        J = randsample(n,num_c,false);  
    
        R_temp = C(I,:)*U_pinv*R;
        C_temp = C*U_pinv*R(:,J);        
    
    
        New_Error = (norm(R_temp.*Samp_ind(I,:) - X_Omega(I,:),'fro') + ... 
                        norm(C_temp.*Samp_ind(:,J)- X_Omega(:,J), 'fro'))/(norm(X_Omega(I,:),'fro') + ... 
                        norm(X_Omega(:,J), 'fro'));  
        if New_Error < TOL || ICURC_ite == max_ite 
            ICURC_time = toc(fct_time); 
            R_temp = C(I_ccs,:)*U_pinv*R;
            C_temp = C*U_pinv*R(:,J_ccs);       
            R = R_temp.*(ones(size(R_temp))-Samp_ind(I_ccs,:))+X_Omega(I_ccs,:);
            C = C_temp.*(ones(size(C_temp))-Samp_ind(:,J_ccs))+X_Omega(:,J_ccs);
            U = 1/2*(R(:,J_ccs)+C(I_ccs,:)); 
            [u,s,v] = svd(U);
            U_pinv = v(:,1:r)*pinv(s(1:r,1:r))*(u(:,1:r))';
            return
        end
    
        %Updating R, C, and U
        R = R_temp.*(ones(size(R_temp))-Samp_ind(I,:))+X_Omega(I,:);
        C = C_temp.*(ones(size(C_temp))-Samp_ind(:,J))+X_Omega(:,J);
        U = 1/2*(R(:,J)+C(I,:)); 
        [u,s,v] = svd(U);
        U_pinv = v(:,1:r)*pinv(s(1:r,1:r))*(u(:,1:r))';
    end