clear all;

sample_ratio = 0.35;
rank = 5;                                                                                                                                                                                                                                                                                                                                      ;
sampling_type = "random column";
proximal_type = "TNN";
max_iteration = 1000;

% %Different sampling types
% T = rank_r_tensor(rank);
% [~, ~, relative_error_list_fully_rand] = tensor_admm(T, sample_ratio, sampling_type, proximal_type, max_iteration);
% [~, iters_fully_rand] = size(relative_error_list_fully_rand);
% 
% sampling_type = "random column";
% [~, ~, relative_error_list_rand_col] = tensor_admm(T, sample_ratio, sampling_type, proximal_type, max_iteration);
% [~, iters_rand_col] = size(relative_error_list_rand_col);
% 
% sampling_type = "uniform column";
% [~, ~,  relative_error_list_uniform_col] = tensor_admm(T, sample_ratio, sampling_type, proximal_type, max_iteration);
% [~, iters_uniform_col] = size(relative_error_list_uniform_col);

test_time = 1;

TNN_relative_errors = zeros(test_time, 1);
TL1_relative_errors = zeros(test_time, 1);
L12_relative_errors = zeros(test_time, 1);
TNN_residue = zeros(test_time, 1);
TL1_residue = zeros(test_time, 1);
L12_residue = zeros(test_time, 1);

%Different Proximal Types
for i=1:test_time
    disp("This is experiment " + i + ":");
    T = rank_r_tensor(rank);
    condition_number = cond_num(T);
    tic
    proximal_type = "TNN";
    [~, relative_error, residue, relative_error_list_TNN] = tensor_admm(T, sample_ratio, sampling_type, proximal_type, max_iteration, "constrained");
    [~, iters_TNN] = size(relative_error_list_TNN);
    TNN_time = round(toc, 4);
    TNN_relative_errors(i) = relative_error;
    TNN_residue(i) = residue;
    disp("TNN relative error: " + relative_error);
    disp("TNN residue: " + residue);
    disp("TNN iterations: " + iters_TNN);
    
    tic
    proximal_type = "TL1";
    [~, relative_error, residue, relative_error_list_TL1] = tensor_admm(T, sample_ratio, sampling_type, proximal_type, max_iteration, "constrained");
    [~, iters_TL1] = size(relative_error_list_TL1);
    TL1_time = round(toc, 4);
    TL1_relative_errors(i) = relative_error;
    TL1_residue(i) = residue;
    disp("TL1 relative error: " + relative_error);
    disp("TL1 residue: " + residue);
    disp("TL1 iterations: " + iters_TL1);
    
    tic
    proximal_type = "L12";
    [~, relative_error,  residue, relative_error_list_L12] = tensor_admm(T, sample_ratio, sampling_type, proximal_type, max_iteration, "constrained");
    [~, iters_L12] = size(relative_error_list_L12);
    L12_time = round(toc, 4);
    L12_relative_errors(i) = relative_error;
    L12_residue(i) = residue;
    disp("L12 relative error: " + relative_error);
    disp("L12 residue: " + residue);
    disp("L12 iterations: " + iters_L12);
    

%     tic
%     proximal_type = "Lp";
%     [~, ~,  relative_error_list_Lp] = tensor_admm(T, sample_ratio, sampling_type, proximal_type, max_iteration);
%     [~, iters_Lp] = size(relative_error_list_Lp);
%     Lp_time = round(toc, 4);

end

% disp("TNN higest result: " + max(TNN_relative_errors));
% disp("TNN lowest result: " + min(TNN_relative_errors));
% disp("TNN average result: " + mean(TNN_relative_errors));
% disp("TNN std result: " + std(TNN_relative_errors));
% disp("");
% disp("TL1 higest result: " + max(TL1_relative_errors));
% disp("TL1 lowest result: " + min(TL1_relative_errors));
% disp("TL1 average result: " + mean(TL1_relative_errors));
% disp("TL1 std result: " + std(TL1_relative_errors));
% disp("");
% disp("L12 higest result: " + max(L12_relative_errors));
% disp("L12 lowest result: " + min(L12_relative_errors));
% disp("L12 average result: " + mean(L12_relative_errors));
% disp("L12 std result: " + std(L12_relative_errors));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %Graphical Illustration Different Sampling Operators
% grid_fully_rand = zeros(iters_fully_rand, 1);
% for i=1:iters_fully_rand
%     grid_fully_rand(i) = i;
% end
% grid_rand_col = zeros(iters_rand_col, 1);
% for i=1:iters_rand_col
%     grid_rand_col(i) = i;
% end
% grid_uniform_col = zeros(iters_uniform_col, 1);
% for i=1:iters_uniform_col
%     grid_uniform_col(i) = i;
% end
% 
% 
% figure(1)
% semilogy(grid_fully_rand, relative_error_list_fully_rand, 'color', 'b');
% hold on;
% semilogy(grid_rand_col, relative_error_list_rand_col, 'color', 'r');
% hold on;
% semilogy(grid_uniform_col, relative_error_list_uniform_col, 'color', 'g');
% hold off;
% legend("Fully Random", "Random Column", "Uniform Column")
% ylabel("$log_{10}(\frac{||X-T||_F}{||T||_F})$", 'Interpreter','latex');
% xlabel("k", 'Interpreter','latex');
% title(["Sampling Ratio: " + 100*sample_ratio + "%, Rank: " + rank,...
%     "Proximal Type: " + proximal_type + ", Max Iterations: " + max_iteration]);

% saveas(figure(1),[pwd '/Results/Different Sampling Operators 2.jpg']);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Graphical Illustration Different Proximal
grid_TNN = zeros(iters_TNN, 1);
for i=1:iters_TNN
    grid_TNN(i) = i;
end
grid_TL1 = zeros(iters_TL1, 1);
for i=1:iters_TL1
    grid_TL1(i) = i;
end
grid_L12 = zeros(iters_L12, 1);
for i=1:iters_L12
    grid_L12(i) = i;
end
% grid_Lp = zeros(iters_Lp, 1);
% for i=1:iters_Lp
%     grid_Lp(i) = i;
% end



figure(1)
semilogy(grid_TNN, relative_error_list_TNN, 'color', 'b');
hold on;
semilogy(grid_TL1, relative_error_list_TL1, 'color', 'r');
hold on;
semilogy(grid_L12, relative_error_list_L12, 'color', 'g');
% hold on;
% semilogy(grid_Lp, relative_error_list_Lp, 'color', 'cyan');
hold off;
legend({"TNN: " + TNN_time + "s", "TL1: " + TL1_time + "s", "L12: " + L12_time + "s"}, 'FontSize', 11)
ylabel("$log_{10}(\frac{||X-T||_F}{||T||_F})$", 'Interpreter','latex');
xlabel("k", 'Interpreter','latex');

title(["Sampling Ratio: " + 100*sample_ratio + "%, Rank: " + rank + ", Condition Number: " + condition_number,...
    "Sampling Type: " + sampling_type + ", Max Iterations: " + max_iteration]);

% figure(1)
% semilogy(grid_L12, relative_error_list_L12, 'color', 'g')
% 
% ylabel("$log_{10}(\frac{||X-T||_F}{||T||_F})$", 'Interpreter','latex');
% xlabel("Iteration Number");
% 
% title(["Sampling Ratio: " + 100*sample_ratio + "%, Rank: " + rank + ", Condition Number: " + condition_number,...
%     "Sampling Type: " + sampling_type + ", Max Iterations: " + max_iteration]);

% saveas(figure(1),[pwd '/Results/Different Proximal Random Column Constrained.jpg']);











