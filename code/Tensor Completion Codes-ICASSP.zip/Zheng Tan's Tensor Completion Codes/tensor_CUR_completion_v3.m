%Tensor CUR Completion
%This is a tensor cross sampling specific CUR algorithm;
%Parameters: T is the entire low rank tensor; 
% sampling_tensor is a tensor with 1 and 0
% sample_ratio is the sampling ratio for the observed tensor;
% I_ccs, J_ccs are the selected row indices and column indices, respectively;
% expected_rank is the expected tubal rank of the completed tensor; for
% convenience, in test it's set to be the actual tubal rank of T;
% max_iteration is the maximum number of iterations in the matrix CUR process.
function [T_completed, fro_error, fro_err_list] = tensor_CUR_completion_v3(T, sampling_tensor, I_ccs, J_ccs, expected_rank, max_iteration)
    %The sampled part
    T_sampled = sampling_tensor .* T;
    T_test = fft(T, [], 3);

    [m, n, o] = size(T);
    T_transformed = fft(T_sampled, [], 3);

    %Try to reduce the tolerance
    params_icurc.TOL = 1e-8;
    params_icurc.max_ite = max_iteration;


    
    X = T_transformed(:,:,1);
    %Calculate the incoherence of the first frontal slice
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Most of the time, the first frontal slice has comparably large
    %coherence than other frontal slices
    %BUT!!Even sometimes its coherence is similar to other frontal slices,
    %the completion result is still bad
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [U, S, V] = svd(X);
    [a, ~] = size(U);
    my_id = eye(a);
    for c=1:o
        M = T_test(:,:,c);
        [U, S, V] = svd(M);
        max_abs = 0;
        for i=1:a
            for j=1:a
                current_abs = abs(my_id(:,j)'*U*V'*my_id(:,j));
                if current_abs > max_abs
                    max_abs = current_abs;
                end
            end
        end
        max_abs = sqrt(m*n/rank(M)) * max_abs;
        disp("Coherence of slice " + c + " is " + max_abs);
    end


    [C, U_pinv, R, ~, fro_err_list] = ICURC(T_test(:,:,1), X, I_ccs, J_ccs, expected_rank, params_icurc);
    X_completed = C*U_pinv*R;
    disp("Current i is 1");
    disp(norm(X_completed-T_test(:,:,1), 'fro')/norm(T_test(:,:,1),'fro'));

    T_completed = nan;
    fro_error = 0;


%     [X_completed] = mat_admm(X, 1500);
%     disp("Current i is 1");
%     disp(norm(X_completed-T_test(:,:,1), 'fro')/norm(T_test(:,:,1),'fro'));
    
%     [rownums, ~] = size(I_ccs);
%     [colnums, ~] = size(J_ccs);
%     C_transformed = zeros(m, colnums, o);
%     U_transformed = zeros(colnums, rownums, o);
%     R_transformed = zeros(rownums, n, o);
% 
%     C_transformed(:,:,1) = X_completed(:, J_ccs);
%     U_transformed(:,:,1) = pinv(X_completed(I_ccs, J_ccs));
%     R_transformed(:,:,1) = X_completed(I_ccs, :);
% 
% 
%     
%     %The first frontal slice is done by ADMM instead
%     %Still can't figure out what's wrong with the first frontal slice
%     for i=2:o
%         X = T_transformed(:,:,i);
% 
%         [C,U_pinv,R, ~] = ICURC(X, I_ccs, J_ccs, expected_rank, params_icurc);
% 
%         C_transformed(:,:,i) = C;
%         U_transformed(:,:,i) = U_pinv;
%         R_transformed(:,:,i) = R;
% 
%         disp("Current i is " + i);
%         disp(norm(C*U_pinv*R-T_test(:,:,i), 'fro')/norm(T_test(:,:,i), 'fro'));
%     end
%     C_tensor = ifft(C_transformed, [], 3); 
%     U_tensor = ifft(U_transformed, [], 3); 
%     R_tensor = ifft(R_transformed, [], 3); 
%     T_completed = t_product(C_tensor, t_product(U_tensor, R_tensor));
% 
% 
%     %Frobenius Norm Error
%     fro_error = norm(T(:)-T_completed(:), 'fro')/norm(T(:), 'fro');
%     disp("Frobenius Norm Error: " + fro_error);

end




%Auxillary function for M_CUR completion
%Matrix ADMM algorithm
%This function has been tested without any issue
function [M_completed] = mat_admm(M_sampled, max_iteration)
    count = 0;

    sampling_matrix = M_sampled;
    sampling_matrix(sampling_matrix~=0) = 1;

    [m, n] = size(M_sampled);
    one_matrix = ones(m, n);

    %Parameter to be adjusted
    ro = 1e-4;
    
    X = M_sampled;
    Y = X;
    W = zeros(m, n);
    while true
        count = count + 1;
        %X problem
        [U, S, V] = svd(Y-W);
        diagonal = diag(S);
        S_shrink = max(abs(diagonal)-1/ro, 0).*sign(diagonal);
        [x, y] = size(S);
        for i=1:min(x, y)
            S(i, i) = S_shrink(i);
        end
        X = U * S * V';
        observed_part_completed = sampling_matrix .* X;
        observed_error = norm(observed_part_completed-M_sampled, 'fro')/norm(M_sampled, 'fro');
        %Y problem
        Y = sampling_matrix .* Y + (one_matrix-sampling_matrix) .* (X+W);
        %W problem
        W = W + (X-Y);
        if count >= max_iteration || observed_error < 1e-10
            disp("Number of iterations is " + count);
            M_completed = X;
            break;
        end
    end
end






