T = rank_r_tensor(10);

[N1, N2, N3] = size(T);
tall_matrix = zeros(N1*N2, N3);
for i=1:N3
    tall_matrix(N1*(i-1)+1:N1*i, :) = T(:,:,i);
end

disp(rank(tall_matrix));
[T1,S,T2]=svd(tall_matrix,'econ');
ss = diag(S);

figure(1)
plot(cumsum(ss)/sum(ss));




[n1,n2,p] = size(T);

H_hat = fft(T, [], 3);

U_hat = zeros(n1,n2,p);
V_hat = zeros(n1,n2,p);
S_hat = zeros(n1,n2,p);
dd = [];
for i=1:2
    [U_hat(:,:,i), S_hat(:,:,i), V_hat(:,:,i)] = svd(H_hat(:,:,i));
    s = diag(S_hat(:,:,i));
    dd = [dd; s];
end

figure(2)
plot(cumsum(dd)/sum(dd));