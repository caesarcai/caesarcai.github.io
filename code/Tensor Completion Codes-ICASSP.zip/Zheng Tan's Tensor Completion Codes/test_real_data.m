clear all;

T = imread("low_rank_window.jpg");
T = im2double(T);

[p, q, r] = size(T);
sampling_ratio = 0.12;
max_iteration_CUR = 800;
sampling_type = "tubal";
%Sample observed data based on the sampling type
[sampling_tensor, I_ccs, J_ccs] = generate_sampling_tensor(p, q, r, sampling_type, sampling_ratio);


T_sampled = T.*sampling_tensor;

figure(1)
title("Origional Image");
image(T);
figure(2)
title("Sampled Image");
image(T_sampled);

% tic
% [T_completed, err_cur] = tensor_CUR_completion_v4(T, sampling_tensor, I_ccs, J_ccs, 15, 0.05, max_iteration_CUR);
% toc

tic
[T_completed, relative_error, ~, ~] = tensor_admm(T, sampling_tensor, 'TNN', 1500, "constrained");
toc

figure(3)
title("Completed Image");
image(T_completed);

SNR = 20 * log10(norm(T,'fro')/norm(T_completed-T, 'fro'));
disp("SNR is " + SNR);




