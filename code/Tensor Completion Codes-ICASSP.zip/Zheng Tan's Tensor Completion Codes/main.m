%Tensor size: 64*64*64; 
%Sampling ratio from 0.4 to 0.2
%Rank from 2 to 6
%Each case iterates for 30 times
%Each ADMM process iterate maximum of 1000 times
%Test for both random column and uniform column cases
%3 proximal types: TNN, TL1, L12
%Results stored in 6 csv files, respectively
sample_ratio = 0.4;
rank = 2;
result_size = 5;
iteration_time = 30;
max_iteration = 1000;

%Random Column TNN
sampling_type = "random column";
proximal_type = "TNN";
result = zeros(result_size, result_size);
for i=1:result_size
    for j=1:result_size
        for k=1:iteration_time
            disp("Sampling type: " + sampling_type + ", proximal type: " + proximal_type + ", rank: " + (rank+(i-1)) + ", sampling ratio: " + (sample_ratio-(j-1)*0.05) + ", iteration: " + k);
            T = rank_r_tensor(rank+(i-1));
            [~, relative_error, residue, ~] = tensor_admm(T, sample_ratio-(j-1)*0.05, sampling_type, proximal_type, max_iteration, "constrained");
            if relative_error <= 10^-5
                result(i, j) = result(i, j) + 1;
            end
        end
    end
end
writematrix(result, "Random Column TNN.csv");

%Random Column TL1
sampling_type = "random column";
proximal_type = "TL1";
result = zeros(result_size, result_size);
for i=1:result_size
    for j=1:result_size
        for k=1:iteration_time
            disp("Sampling type: " + sampling_type + ", proximal type: " + proximal_type + ", rank: " + (rank+(i-1)) + ", sampling ratio: " + (sample_ratio-(j-1)*0.05) + ", iteration: " + k);
            T = rank_r_tensor(rank+(i-1));
            [~, relative_error, residue, ~] = tensor_admm(T, sample_ratio-(j-1)*0.05, sampling_type, proximal_type, max_iteration, "constrained");
            if relative_error <= 10^-5
                result(i, j) = result(i, j) + 1;
            end
        end
    end
end
writematrix(result, "Random Column TL1.csv");

%Random Column L12
sampling_type = "random column";
proximal_type = "L12";
result = zeros(result_size, result_size);
for i=1:result_size
    for j=1:result_size
        for k=1:iteration_time
            disp("Sampling type: " + sampling_type + ", proximal type: " + proximal_type + ", rank: " + (rank+(i-1)) + ", sampling ratio: " + (sample_ratio-(j-1)*0.05) + ", iteration: " + k);
            T = rank_r_tensor(rank+(i-1));
            [~, relative_error, residue, ~] = tensor_admm(T, sample_ratio-(j-1)*0.05, sampling_type, proximal_type, max_iteration, "constrained");
            if relative_error <= 10^-5
                result(i, j) = result(i, j) + 1;
            end
        end
    end
end
writematrix(result, "Random Column L12.csv");

%Uniform Column TNN
sampling_type = "uniform column";
proximal_type = "TNN";
result = zeros(result_size, result_size);
for i=1:result_size
    for j=1:result_size
        for k=1:iteration_time
            disp("Sampling type: " + sampling_type + ", proximal type: " + proximal_type + ", rank: " + (rank+(i-1)) + ", sampling ratio: " + (sample_ratio-(j-1)*0.05) + ", iteration: " + k);
            T = rank_r_tensor(rank+(i-1));
            [~, relative_error, residue, ~] = tensor_admm(T, sample_ratio-(j-1)*0.05, sampling_type, proximal_type, max_iteration, "constrained");
            if relative_error <= 10^-5
                result(i, j) = result(i, j) + 1;
            end
        end
    end
end
writematrix(result, "Uniform Column TNN.csv");

%Uniform Column TL1
sampling_type = "uniform column";
proximal_type = "TL1";
result = zeros(result_size, result_size);
for i=1:result_size
    for j=1:result_size
        for k=1:iteration_time
            disp("Sampling type: " + sampling_type + ", proximal type: " + proximal_type + ", rank: " + (rank+(i-1)) + ", sampling ratio: " + (sample_ratio-(j-1)*0.05) + ", iteration: " + k);
            T = rank_r_tensor(rank+(i-1));
            [~, relative_error, residue, ~] = tensor_admm(T, sample_ratio-(j-1)*0.05, sampling_type, proximal_type, max_iteration, "constrained");
            if relative_error <= 10^-5
                result(i, j) = result(i, j) + 1;
            end
        end
    end
end
writematrix(result, "Uniform Column TL1.csv");

%Uniform Column L12
sampling_type = "uniform column";
proximal_type = "L12";
result = zeros(result_size, result_size);
for i=1:result_size
    for j=1:result_size
        for k=1:iteration_time
            disp("Sampling type: " + sampling_type + ", proximal type: " + proximal_type + ", rank: " + (rank+(i-1)) + ", sampling ratio: " + (sample_ratio-(j-1)*0.05) + ", iteration: " + k);
            T = rank_r_tensor(rank+(i-1));
            [~, relative_error, residue, ~] = tensor_admm(T, sample_ratio-(j-1)*0.05, sampling_type, proximal_type, max_iteration, "constrained");
            if relative_error <= 10^-5
                result(i, j) = result(i, j) + 1;
            end
        end
    end
end
writematrix(result, "Uniform Column L12.csv");