clear all;


max_iteration_CUR = 800;
max_iteration_ADMM = 800;

p = 256;
q = 256;
r = 50;

% sampling_ratios = [0.1, 0.15, 0.2, 0.25, 0.3];
sampling_ratios = [0.35, 0.4, 0.45, 0.5, 0.55];
tensor_rank = 5;
sampling_type = "tubal";

avg_relative_errors_cur = zeros(5, 1);
avg_relative_errors_admm = zeros(5, 1);
experiment_time = 1;

for i=1:5
    sampling_ratio = sampling_ratios(i);
    results_cur = zeros(experiment_time, 1);
    results_admm = zeros(experiment_time, 1);
    for j=1:experiment_time
        disp("Current Sampling Ratio is " + sampling_ratio + "; Current Experiment Time is " + j);
        T = rank_r_tensor(tensor_rank, p, q, r);
        %Sample observed data based on the sampling type
        [sampling_tensor, I_ccs, J_ccs] = generate_sampling_tensor(p, q, r, sampling_type, sampling_ratio);
        
        
%         disp("CUR tubal sampling results:");
%         tic
%         [~, err_cur] = tensor_CUR_completion_v4(T, sampling_tensor, I_ccs, J_ccs, tensor_rank, 0.1, max_iteration_CUR);
%         toc;
%         disp("Relateive Error for CUR is: " + err_cur);
%         avg_relative_errors_cur(i) = avg_relative_errors_cur(i) + err_cur;

    
%         disp(" ");
    
        disp("ADMM tubal sampling results:");
        tic
        [~, err_admm, ~, ~] = tensor_admm(T, sampling_tensor, "TNN", max_iteration_ADMM, 'constrained');
        toc;
        disp("Relateive Error for ADMM is: " + err_admm);
        avg_relative_errors_admm(i) = avg_relative_errors_admm(i) + err_admm;

        disp(" ");
    end
%     avg_relative_errors_cur(i) = avg_relative_errors_cur(i)/experiment_time;
%     avg_relative_errors_admm(i) = avg_relative_errors_admm(i)/experiment_time;
end


figure(1)
semilogy(sampling_ratios, avg_relative_errors_admm, 'k*-');
xticks(sampling_ratios);
% hold on;
% semilogy(sampling_ratios, avg_relative_errors_admm, 'g-.');
% xticks(sampling_ratios);
% hold off;
% legend("CUR", "ADMM", "Location", "best");

% set(gca,'FontName','times','FontSize',font_size,'TickLabelInterpreter','Latex');
% set(gcf,'Position',[100,100,width,heigth]);















