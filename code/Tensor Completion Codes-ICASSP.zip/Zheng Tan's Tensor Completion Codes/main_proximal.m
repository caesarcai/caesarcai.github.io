T = rank_r_tensor(3);



[T_completed, relative_error, relative_error_list] = tensor_admm(T, 0.45, 'fully random', 'L12', 50);

[~, len] = size(relative_error_list);
grid = zeros(len);
relative_errors = zeros(len);
for i=1:size(grid)
    grid(i) = i;
    relative_errors(i) = log10(relative_error_list{i}); 
end

figure(1)
plot(grid, relative_errors);
print('-depsc2', 'test.eps')


