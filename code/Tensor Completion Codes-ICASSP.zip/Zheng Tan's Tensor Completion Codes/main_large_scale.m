%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Setup
sample_ratio = 0.55;                    %Lowest(Starting) sample ratio
rank = 2;                               %Lowest(Starting) rank
result_size = 10;                       %Size of the illustration matrix   
iteration_time = 50;                    %Times of experiments for each entry

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %Tensor ADMM for fully random sampling
% %Rank from 2 to 11
% %Sampling ratio from 0.55 to 0.05
% result_fully_random = zeros(result_size, result_size);
% for i=1:result_size
%     for j=1:result_size
%         for k=1:iteration_time
%             T = rank_r_tensor(rank+(i-1));
%             [~, relative_error] = tensor_admm(T, sample_ratio - (j-1)*0.05, "fully random");
%             if relative_error <= 10^-5
%                 result_fully_random(i, j) = result_fully_random(i, j) + 1;
%             end
%         end
%     end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reset the setups
sample_ratio = 0.55;                    %Lowest(Starting) sample ratio
rank = 2;                               %Lowest(Starting) rank
result_size = 10;                       %Size of the illustration matrix   
iteration_time = 50;                    %Times of experiments for each entry

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Tensor ADMM for random column sampling
%Rank from 2 to 11
%Sampling ratio from 0.55 to 0.05
result_random_column = zeros(result_size, result_size);
for i=1:result_size
    i
    for j=1:result_size
        for k=1:iteration_time
            T = rank_r_tensor(rank+(i-1));
            [~, relative_error] = tensor_admm(T, sample_ratio - (j-1)*0.05, "random column");
            if relative_error <= 10^-5
                result_random_column(i, j) = result_random_column(i, j) + 1;
            end
        end
    end
end

figure(1)
imshow(result_fully_random);
figure(2)
imshow(result_random_column);


save results-random-column









