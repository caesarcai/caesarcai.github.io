function [C,U_pinv,R, ICURC_time] = ICURC_v2(X, r, params_ICURC, resample_times, I_css_final, J_css_final, X_Omega_UR_final)
%Return the CUR components of result of solved Matrix Completion problem
%under Cross-Concentrated Sampling (CCS). 
%
%Inputs:
%   X_Omega_css - observed data matrix based on CSS sampling model
%   I_css - row indices of the selected row submatrix
%   J_css - column indices of the selected column submatrix
%   r : rank of targt X
%   params_ICURC - parameter structure containing the following fields:
%       TOL,max_ite - stopping crICURC_iteria
%           defaults = 1e-4 (TOL), 500 (mxitr)
%       eta - step size
%           default = [1, 1, 1] for [eta_C, eat_R, era_U], step sizes for
%           updating C, R, and U respectively 
%       steps_are1 - if all step sizes are 1
%           default = true

%Outputs:
%   C, U_pinv, R - The CUR components of recovered X
%   ICURC_time -Function execution time
%   ICURC_ite - Number of ICURC_iterations required

    %Setup the basic parameters
    if(~exist('params_ICURC','var'))
        params_ICURC=struct();
    end
    params_ICURC = SetDefaultParams_ICURC(params_ICURC);
%     eta=params_ICURC.eta;
%     TOL=params_ICURC.TOL;
    max_iter = params_ICURC.max_ite;
    params_ICURC.max_ite = round(max_iter/resample_times);
%     steps_are1=params_ICURC.steps_are1;
    %Parameters for generating random columns&samples each iteration
    params_CCS.p = 0.6;         %uniform observation rate on the submatrices
    params_CCS.delta = 0.8;     %percentage of sampled columns or rows

    %Randomly generate I_css, J_css
    tic
    for a=1:resample_times
        if a ~= resample_times
            [X_Omega_UR, I_css, J_css] = CCS(X, params_CCS);
        else
            I_css = I_css_final;
            J_css = J_css_final;
            X_Omega_UR = X_Omega_UR_final;
        end
        [C, U_pinv, R, ~] = ICURC(X_Omega_UR, I_css, J_css, r, params_ICURC);

        X(:, J_css) = C;
        X(I_css, :) = R;
        X(I_css, J_css) = pinv(U_pinv);
    end
    ICURC_time = toc;

end
