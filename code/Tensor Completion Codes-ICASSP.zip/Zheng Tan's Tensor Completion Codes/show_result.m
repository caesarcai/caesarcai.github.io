clear all;
sampling_ratios = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55];
y_limits = [10^-8, 10^-7, 10^-6, 10^-5, 10^-4, 10^-3, 10^-2, 10^-1];


%DO NOT CHANGE THIS PART AT ANY TIME!!!!!
avg_relative_errors_cur_r3 = [1.6821e-4, 1.7581e-6, 1.2458e-6, 1.0095e-6, 8.8039e-7, 7.5468e-07, 6.8717e-07, 6.0046e-07, 5.1438e-07, 4.4065e-07];
avg_relative_errors_admm_r3 = [8.2627e-5, 3.3183e-6, 1.2717e-6, 1.078e-6, 1.0497e-6,1.0354e-06, 1.0728e-06, 9.6469e-07, 1.0079e-06, 8.7430e-07];
avg_relative_errors_cur_nonresample_r3 = [0.1009, 0.0708, 0.0462, 0.0296, 0.0318, 0.0208, 0.0266, 0.0238, 0.0208, 0.0163];
avg_relative_errors_admm_l12_r3 = [5.8382e-05, 1.1437e-06, 1.1407e-06, 1.1940e-06, 9.5549e-07, 1.0599e-06, 1.0714e-06, 1.1014e-06, 1.0225e-06, 7.4467e-07];


avg_relative_errors_cur_r5 = [0.0026, 0.0024, 0.0021, 0.0011, 8.19120e-07, 7.4636e-07, 6.8862e-07, 6.0147e-07, 5.5475e-07, 5.0781e-07];
avg_relative_errors_admm_r5 = [0.2170, 0.0083, 9.1972e-06, 8.9871e-06, 8.9921e-06, 8.8554e-06, 8.7609e-06, 8.1276e-06, 8.1400e-06, 8.4233e-06];
avg_relative_errors_cur_nonresample_r5 = [0.2354, 0.12231, 0.0955, 0.060569, 0.046756, 0.03677, 0.037662, 0.029451, 0.028369, 0.029723];
avg_relative_errors_admm_l12_r5 = [0.10005, 9.65e-06, 1.1992e-06, 1.0898e-06, 1.128e-06, 1.085e-06, 1.2388e-06, 1.0916e-06, 9.9147e-07, 1.0503e-06];


avg_relative_errors_cur_r7 = [0.0050,0.0026,0.0024,0.0022,0.0020,0.0018,0.0015,0.0013,0.0011,0.0009];
avg_relative_errors_admm_r7 = [0.0051, 7.8973e-05, 2.625e-06, 1.696e-06, 1.5081e-06, 1.3181e-06, 1.1573e-06, 1.1003e-06, 1.1417e-06, 9.934e-07];

dimension = [6, 7, 8, 9, 10];
cur_dim_time = [0.55164, 1.0007, 1.711, 4.3305, 19.9024];
admm_dim_time = [19.0013, 15.5426, 72.2676, 354.5685, 2568.7919];
cur_nonresample_dim_time = [1.3865, 5.8461, 8.473, 24.1355, 86.6579];
admm_l12_dim_time = [18.4528, 16.6631, 62.7458, 311.1115, 2236.9465];


% figure(1)
% semilogy(sampling_ratios, avg_relative_errors_admm_r3, 'g^-.', 'LineWidth',2);
% xticks(sampling_ratios);
% yticks(y_limits);
% hold on;
% % semilogy(sampling_ratios, avg_relative_errors_cur_nonresample_r3, 'r+--');
% % xticks(sampling_ratios);
% % yticks(y_limits);
% % hold on;
% semilogy(sampling_ratios, avg_relative_errors_admm_l12_r3, 'b^-.', 'LineWidth',2);
% xticks(sampling_ratios);
% yticks(y_limits);
% hold on;
% semilogy(sampling_ratios, avg_relative_errors_cur_r3, 'k*-', 'LineWidth',2);
% xticks(sampling_ratios);
% yticks(y_limits);
% xticklabels({'0.1', '0.15', '0.2', '0.25', '0.3', '0.35', '0.4', '0.45', '0.5', '0.55'});
% a = get(gca,'XTickLabel');  
% set(gca,'XTickLabel',a,'fontsize', 13);
% hold off;
% legend("TNN", "TL12", "TCCUR", "Location", "best", 'fontsize', 13);
% xlim([0.1, 0.55]);
% ylim([10^-8, 10^-1]);
% print('-depsc2','Rank 3 Result.eps')



figure(2)
semilogy(sampling_ratios, avg_relative_errors_admm_r5, 'g^-.', 'LineWidth',2);
hold on;
% semilogy(sampling_ratios, avg_relative_errors_cur_nonresample_r5, 'r+--');
% xticks(sampling_ratios);
% yticks(y_limits);
% hold on;
semilogy(sampling_ratios, avg_relative_errors_admm_l12_r5, 'b^-.', 'LineWidth',2);
hold on;
semilogy(sampling_ratios, avg_relative_errors_cur_r5, 'k*-', 'LineWidth',2);
xticks(sampling_ratios);
yticks(y_limits);
xticklabels({'0.1', '0.15', '0.2', '0.25', '0.3', '0.35', '0.4', '0.45', '0.5', '0.55'});
a = get(gca,'XTickLabel');  
set(gca,'XTickLabel',a,'fontsize', 13)
legend("TNN", "TL12", "TCCUR", "Location", "best", 'fontsize', 13);
xlim([0.1, 0.55]);
ylim([10^-8, 10^-1]);
ax = gca
ax.XAxis.Exponent = -2;
hold off;
print('-depsc2','Rank 5 Result.eps')




% figure(3)
% plot(dimension, admm_dim_time, 'g^-.', 'LineWidth',2);
% hold on;
% plot(dimension, admm_l12_dim_time, 'b^-.', 'LineWidth',2);
% hold on;
% % plot(dimension, cur_nonresample_dim_time, 'r+--', 'LineWidth',2);
% % hold on;
% plot(dimension, cur_dim_time, 'k*-', 'LineWidth',2);
% xticks(dimension);
% xticklabels({'2^6','2^7','2^8','2^9','2^{10}'});
% a = get(gca,'XTickLabel');  
% set(gca,'XTickLabel',a,'fontsize',18)
% hold off;
% 
% % xlabel("Dimension 2^n\times 2^n\times 32");
% % set(gca,'TickLabelInterpreter','latex')
% legend("TNN", "TL12", "TCCUR", "Location", "northwest", 'fontsize', 18);
% print('-depsc2','Dimension vs time.eps')