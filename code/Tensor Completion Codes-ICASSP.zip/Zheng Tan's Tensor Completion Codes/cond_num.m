%Calculate the condition number of a tensor
function n = cond_num(T)
    [N1, N2, N3] = size(T);
    %Turn the tensor into a cyclic matrix
    circ_T = zeros(N1*N3, N2*N3);
    for j=1:N3
        for i=1:N3
            current_round = mod(i+j-2, N3);
            circ_T(current_round*N1+1:(current_round+1)*N1,(j-1)*N2+1:j*N2) = T(:,:,i);
        end
    end
    
    n = cond(circ_T);
end