function C = pythag(A,B)

C = sqrt(abs(A).^2 + abs(B).^2);